
    (function() {
      var baseURL = "https://cdn.shopify.com/shopifycloud/checkout-web/assets/";
      var scripts = ["https://cdn.shopify.com/shopifycloud/checkout-web/assets/runtime.esm.ja.ca8ae778eacea0bd78a9.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/922.esm.ja.491ba453e9ec7e56239a.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/139.esm.ja.de79e341375f48184d46.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/681.esm.ja.ce685673c57feb056fc4.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/app.esm.ja.43724178545ccb909104.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/751.esm.ja.e7c87ec84b88595f964f.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/21.esm.ja.673ea387d278b8072e41.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/100.esm.ja.ad2f643ddfcd69662b67.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/OnePage.esm.ja.3e0498cfc6740cb1e005.js"];
      var styles = ["https://cdn.shopify.com/shopifycloud/checkout-web/assets/922.esm.ja.4d3f797635fd7e454be6.css","https://cdn.shopify.com/shopifycloud/checkout-web/assets/app.esm.ja.4fac962c00cbe417416a.css","https://cdn.shopify.com/shopifycloud/checkout-web/assets/21.esm.ja.cba6ce0195ec0c2405de.css","https://cdn.shopify.com/shopifycloud/checkout-web/assets/268.esm.ja.1c7846d6c4700c76300f.css"];
      var fontPreconnectUrls = ["https://fonts.shopifycdn.com"];
      var fontPrefetchUrls = ["https://fonts.shopifycdn.com/open_sans/opensans_n4.5460e0463a398b1075386f51084d8aa756bafb17.woff2?h1=a29uYXZpLmpw&hmac=f67d54334aa87785b312553c4677244c6feb26e7c37753056d1e1ca2b75d348f","https://fonts.shopifycdn.com/open_sans/opensans_n6.63a74f6cbbfef729fb07955b2d5b4cc83273862e.woff2?h1=a29uYXZpLmpw&hmac=567054d1c6c77d70578c0ad601399f814bde248275fbdfe7f25c689a6b29fff2"];
      var imgPrefetchUrls = ["https://cdn.shopify.com/s/files/1/0588/7924/6515/files/37_3x_6163caf9-8155-47f8-9502-28f3cce405be_x320.png?v=1643213326"];

      function preconnect(url, callback) {
        var link = document.createElement('link');
        link.rel = 'dns-prefetch preconnect';
        link.href = url;
        link.crossOrigin = '';
        link.onload = link.onerror = callback;
        document.head.appendChild(link);
      }

      function preconnectAssets() {
        var resources = [baseURL].concat(fontPreconnectUrls);
        var index = 0;
        (function next() {
          var res = resources[index++];
          if (res) preconnect(res[0], next);
        })();
      }

      function prefetch(url, as, callback) {
        var link = document.createElement('link');
        if (link.relList.supports('prefetch')) {
          link.rel = 'prefetch';
          link.fetchPriority = 'low';
          link.as = as;
          if (as === 'font') link.type = 'font/woff2';
          link.href = url;
          link.crossOrigin = '';
          link.onload = link.onerror = callback;
          document.head.appendChild(link);
        } else {
          var xhr = new XMLHttpRequest();
          xhr.open('GET', url, true);
          xhr.onloadend = callback;
          xhr.send();
        }
      }

      function prefetchAssets() {
        var resources = [].concat(
          scripts.map(function(url) { return [url, 'script']; }),
          styles.map(function(url) { return [url, 'style']; }),
          fontPrefetchUrls.map(function(url) { return [url, 'font']; }),
          imgPrefetchUrls.map(function(url) { return [url, 'image']; })
        );
        var index = 0;
        (function next() {
          var res = resources[index++];
          if (res) prefetch(res[0], res[1], next);
        })();
      }

      function onLoaded() {
        preconnectAssets();
        prefetchAssets();
      }

      if (document.readyState === 'complete') {
        onLoaded();
      } else {
        addEventListener('load', onLoaded);
      }
    })();
  